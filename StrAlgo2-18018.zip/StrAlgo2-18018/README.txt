TUGAS BESAR II STRATEGI ALGORITMA

Simulasi Penyebaran Virus Penyakit dengan Memanfaatkan Algoritma BFS untuk Penelusuran pada Graf

oleh:
Steve Bezalel Iman G. 13518018
Anna Elvira Hartoyo 13518045
Yonatan Viody 13518120

Penggunaan di Windows:
1. Jalankan Visual Studio
2. Build VirusSimulation.sln pada foler src
3. Run